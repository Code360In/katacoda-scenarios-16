# 5GgENB simulate ngap+5g-nas



## web page:

5GgENB


## Overview

```
# python 5GgEnb.py -r
2020/08/22  17:23:09,130 [INFO] [796]  ctrl + c to stop
2020/08/22  17:23:09,130 [INFO] [797]  ________________________________________
2020/08/22  17:23:09,130 [INFO] [798]  5GgENBv1530 version:0.0.3
2020/08/22  17:23:09,131 [INFO] [799]  ________________________________________
2020/08/22  17:23:09,131 [INFO] [816]  RestAPI addr: 135.228.12.42 9094
2020/08/22  17:23:09,131 [INFO] [817]  ________________________________________
2020/08/22  17:23:09,132 [INFO] [833]  SCTP client=192.167.1.4 server=192.168.1.8 port=38412
2020/08/22  17:23:09,132 [INFO] [834]  ________________________________________
2020/08/22  17:23:09,133 [INFO] [130]  Initializing gtpu
2020/08/22  17:23:09,133 [INFO] [745]  ________________________________________
2020/08/22  17:23:09,133 [INFO] [746]  NGSetupRequest
SEND--> initiatingMessage : {
  procedureCode 21,
  criticality reject,
  value NGSetupRequest: {
    protocolIEs {
      {
        id 27,

```


![](doc/plantuml5GgEnb.png)


## REST API /TESTNAME

```
1) 5greg

a) initial registration
b) PDU session establishment request
c) PDU session release request
d) Deregistration request (UE originating) 

```

```
2)  5gngsetup

 a) ng setup request/response
```

## History
v0.0.4  2020/08/22 

```
a) add new lib/doc dir
b) meny option -t to execute test by name
c) msg in hex to config.yam
```

v0.0.3 2020/08/22 
```
RESTapi HTTP2
```

v0.0.2  2020/08/22 
```
clean-up,validation 5gnas, nodelay ("-n" )
```

v0.0.1 2020/08/22 
```
initial version 
```
## 
