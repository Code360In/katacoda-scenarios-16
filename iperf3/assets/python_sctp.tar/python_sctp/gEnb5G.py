# -*- coding: UTF-8 -*-
#!/usr/bin/env python
#######################################################
# vpavesi
# 5GgENB simulate ngap + 5g-nas
# restApi http2 
# august 2020
version="0.0.4"
#######################################################

##################################
import os, sys
from lib.common import *
#from lib.restapi import http2restapi
import lib.gtpu as UP
from lib.callp import *
import logging
import optparse
import socket
import threading
import yaml
 
if (sys.version_info > (3, 0)): 
  from lib.restapi3 import http2restapi3
else:
  from lib.restapi2 import http2restapi2
# py2-3
try:  
  from Queue import Queue
except ImportError:
  from queue import Queue
####import########################

##################################
# main
if __name__ == "__main__":

 try:  

    ##################################
    # read config yaml
    with open("config.yml", 'r') as ymlfile:
      cfg = yaml.load(ymlfile)
    ##################################

    #############################
    # define logging   	
    logging.basicConfig(format='%(asctime)s [%(name)s] [%(levelname)s] [%(lineno)d]  %(message)s',level=logging.INFO)
    logging.info('ctrl + c or z to stop')
    logging.info(printSepChar())
    logging.info('5GgENBv1530 version:' +version)
    logging.info(printSepChar()) 
    # parser arguments
    usage = "usage: %prog [options] -n -r"
    parser = optparse.OptionParser(usage)
    parser.add_option("--nodealy","-n", help="no delay",action="store_true",default=False)
    parser.add_option("--restApi","-r", help="restAPI server start",action="store_true",default=False)
    parser.add_option("--debug","-d", help="debug",action="store_true",default=False)
    parser.add_option("--testname","-t", help="test name: 5greg,5gngsetup")
    (options, args) = parser.parse_args()
    nodelay = options.nodealy
    restApi_start = options.restApi
    testname = options.testname
    
    # debug mode
    if options.debug == True: 
      logging.basicConfig(format='%(asctime)s [%(name)s] [%(levelname)s] [%(lineno)d]  %(message)s',level=0)
    #############################

    #############################
    # sctp init  
    sctpport = cfg['main']['sctpport']
    clientSCTPgenb = cfg['main']['gEnbIpaddr']
    serverSCTPamf = cfg['main']['amfN2Ipaddr']
    srcaddr = (clientSCTPgenb, sctpport) 
    dstaddr = (serverSCTPamf, sctpport) 
    logging.info("SCTP: client=%s",clientSCTPgenb)
    logging.info("SCTP: server=%s",serverSCTPamf)
    logging.info("SCTP: port=%i" ,sctpport)
    logging.info(printSepChar()) 
    #socket.IPPROTO_SCTP = 132
    enb_sctp = socket.socket(socket.AF_INET,socket.SOCK_STREAM,132)
    enb_sctp.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 1024)
    enb_sctp.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 1024)
    enb_sctp.bind(srcaddr)
    enb_sctp.connect(dstaddr)
    #############################

    #############################
    # GTPU initialize
    UserPlaneLocalIpaddr = cfg['userplane']['Ipaddr']
    UserPlanePort = cfg['userplane']['port']
    gtpuserplane = UP.GtpU(UserPlaneLocalIpaddr, UserPlanePort)
    logging.info(printSepChar()) 
    #############################

    #############################
    # NGSetupRequest
    queuengSetup= Queue()
    resturi = "5gngsetup"
    threadstartNgSetup = threading.Thread(target = callp_5gngsetup(enb_sctp,gtpuserplane,queuengSetup,resturi,restApi_start,nodelay))
    threadstartNgSetup.start()
    threadstartNgSetup.join()
    result = queuengSetup.get()
    logging.info(result)
    #############################

    #############################
    if restApi_start == False:
      if testname:
        #############################
        # testname
        queueInitialReg = Queue()
        resturi = testname
        threadstartInitialReg = threading.Thread(target = callp_testname(enb_sctp,gtpuserplane,queueInitialReg,resturi,suci,restApi_start,nodelay,testname))
        threadstartInitialReg.start()
        threadstartInitialReg.join()
        result = queueInitialReg.get(False)
        logging.info(result)
      else:
        #############################
        # initial registration
        queueInitialReg = Queue()
        resturi = "5greg"
        threadstartInitialReg = threading.Thread(target = callp_5greg(enb_sctp,gtpuserplane,queueInitialReg,resturi,suci,restApi_start,nodelay))
        threadstartInitialReg.start()
        threadstartInitialReg.join()
        result = queueInitialReg.get(False)
        logging.info(result)

    #############################
    # rest api start 
    # http2
    if restApi_start == True:
      try:
        restapi_ipaddr = ( cfg['restApi']['Ipaddr'])
        restapi_port = ( cfg['restApi']['port'])
        logging.info("RestAPI addr: %s %i" , restapi_ipaddr , restapi_port )     
        logging.info(printSepChar())
        # py3
        if (sys.version_info > (3, 0)): 
          http2restapi3(enb_sctp,gtpuserplane,restapi_ipaddr,restapi_port)
        else:
          http2restapi2(enb_sctp,gtpuserplane,restapi_ipaddr,restapi_port)

      except KeyboardInterrupt:
        print(1)
        enb_sctp.close()
        sys.exit()
      except Exception as inst:
        logging.debug("%s",inst.args)
        enb_sctp.close()
        sys.exit()
    #############################
 
 except KeyboardInterrupt:
   logging.info("task complete!")
   sys.exit()
   
####main##########################
##################################