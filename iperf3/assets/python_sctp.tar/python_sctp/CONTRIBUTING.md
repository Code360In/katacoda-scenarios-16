## to help

a) install git/python2/3
```
1) git https://git-scm.com/downloads
2) python https://www.python.org/downloads/
3) visualcode https://code.visualstudio.com/download
```

b) clone repository
```
 $ git clone
```

c) get updates
```
  $ git pull
```

d) git commit / pull request. 
```
 $ git commit -am  "big load still improvement"
 $ git push 
```

e) create new version/tag
```
 $ git tag -a v0.0.4 -m "big load still improvement"
 $ git push origin v0.0.4
```

f) copy ASN.1 from 3GPP doc and generate python class
```
https://github.com/P1sec/pycrate/wiki/Using-the-pycrate-asn1-runtime

$ pycrate_asn1compile.py -i /tools/python/asn/specs/ -o /tools/python/asn/specs/NGAP.py

```

