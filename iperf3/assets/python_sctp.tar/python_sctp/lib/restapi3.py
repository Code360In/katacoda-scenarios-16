# -*- coding: UTF-8 -*-
#!/usr/bin/env python
# restApi
# vpavesi april 2019

##################################
import os, sys
import logging
import binascii
import threading
from lib.callp import *
import asyncio
import io
import json
import collections
from typing import List, Tuple

from h2.config import H2Configuration
from h2.connection import H2Connection
from h2.events import (
    ConnectionTerminated, DataReceived, RequestReceived, StreamEnded
)
from h2.errors import ErrorCodes
from h2.exceptions import ProtocolError

RequestData = collections.namedtuple('RequestData', ['headers', 'data'])
       
# py2-3
try:  
  from Queue import Queue
except ImportError:
  from queue import Queue
##################################

##################################
def http2restapi3(enb_sctp,gtpuserplane,restapi_ipaddr,restapi_port):

  class H2Protocol(asyncio.Protocol):
    def __init__(self):
        config = H2Configuration(client_side=False, header_encoding='utf-8')
        self.conn = H2Connection(config=config)
        self.transport = None
        self.stream_data = {}

    def connection_made(self, transport: asyncio.Transport):
        self.transport = transport
        self.conn.initiate_connection()
        self.transport.write(self.conn.data_to_send())

    def data_received(self, data: bytes):
        try:
            events = self.conn.receive_data(data)
        except ProtocolError as e:
            self.transport.write(self.conn.data_to_send())
            self.transport.close()
        else:
            self.transport.write(self.conn.data_to_send())
            for event in events:
                if isinstance(event, RequestReceived):
                    self.request_received(event.headers, event.stream_id)
                elif isinstance(event, DataReceived):
                    self.receive_data(event.data, event.stream_id)
                elif isinstance(event, StreamEnded):
                    self.stream_complete(event.stream_id)
                elif isinstance(event, ConnectionTerminated):
                    self.transport.close()

                self.transport.write(self.conn.data_to_send())

    def request_received(self, headers: List[Tuple[str, str]], stream_id: int):
        headers = collections.OrderedDict(headers)
        method = headers[':method']

        # We only support GET and POST.
        if method not in ('GET'):
            self.return_405(headers, stream_id)
            return

        # Store off the request data.
        request_data = RequestData(headers, io.BytesIO())
        self.stream_data[stream_id] = request_data

    def stream_complete(self, stream_id: int):
        """
        When a stream is complete, we can send our response.
        """
        try:
            request_data = self.stream_data[stream_id]
        except KeyError:
            # Just return, we probably 405'd this already
            return

        headers = request_data.headers
        path = headers[':path']
        resturi = path.strip( '/' )  
        result ={resturi:[{'result': 'failed'}]}
        
        # start api
        if "5gngsetup" in  resturi:
          result= ngsetup5gThread(path,enb_sctp,gtpuserplane,resturi)  
        elif "5greg" in  resturi:
          result= reg5gThread(path,enb_sctp,gtpuserplane,resturi)
        
        # fill response json 
        data = json.dumps(result).encode('utf-8')

        response_headers = (
            (':status', '200'),
            ('content-type', 'application/json'),
            ('content-length', str(len(data))),
            ('server', '5GgENBrestApi'),
        )
        self.conn.send_headers(stream_id, response_headers)
        self.conn.send_data(stream_id, data, end_stream=True)

    def return_405(self, headers: List[Tuple[str, str]], stream_id: int):
        """
        We don't support the given method, so we want to return a 405 response.
        """
        response_headers = (
            (':status', '405'),
            ('content-length', '0'),
            ('server', 'asyncio-h2'),
        )
        self.conn.send_headers(stream_id, response_headers, end_stream=True)

    def receive_data(self, data: bytes, stream_id: int):
        """
        We've received some data on a stream. If that stream is one we're
        expecting data on, save it off. Otherwise, reset the stream.
        """
        try:
            stream_data = self.stream_data[stream_id]
        except KeyError:
            self.conn.reset_stream(
                stream_id, error_code=ErrorCodes.PROTOCOL_ERROR
            )
        else:
            stream_data.data.write(data)


  loop = asyncio.get_event_loop()
  # Each client connection will create a new protocol instance
  coro = loop.create_server(H2Protocol, restapi_ipaddr, restapi_port, ssl=None)
  server = loop.run_until_complete(coro)

  # Serve requests until Ctrl+C is pressed  
  try:
    loop.run_forever()
  except KeyboardInterrupt:
    pass

  # Close the server
  server.close()
  loop.run_until_complete(server.wait_closed())
  loop.close()
##################################


##################################
def reg5gThread(path,enb_sctp,gtpuserplane,resturi):
  resturi = "5greg"
  #5greg/suci/000d-01-216354-000000000000001000
  suciurip = (path).split('/')[3]
  suciuripsuf = suciurip.replace("-", "") 
  sucirestapi = binascii.unhexlify(suciuripsuf)  # 5GS mobile identity 000d-01-216354-000000000000001000
  restapiqueue = Queue()
  callp_5greg(enb_sctp,gtpuserplane,restapiqueue,resturi,sucirestapi,True,False)
  result = restapiqueue.get(False)
  logging.info(result)
  return result 
##################################

##################################
def ngsetup5gThread(path,enb_sctp,gtpuserplane,resturi):
  restapiqueue = Queue()
  callp_5gngsetup(enb_sctp,gtpuserplane,restapiqueue,resturi,True,False)
  result = restapiqueue.get(False)
  logging.info(result)
  return result    
##################################



