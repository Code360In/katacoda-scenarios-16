# -*- coding: UTF-8 -*-
#!/usr/bin/env python
# callp
# vpavesi april 2019

##################################
import os, sys
from lib.common import *
import lib.ngapv1530 as NGAP
import yaml
import logging
import random
import socket
import struct
import time
import yaml

try:
    input = raw_input
except NameError:
    pass

##################################


##################################
# read config yaml
with open("config.yml", 'r') as ymlfile:
  cfg = yaml.load(ymlfile)
##################################

##################################
# MSG TEMPLATE.

# NGAP
MSG_TEMPLATE_NGAP_NGSETUP = binascii.unhexlify(cfg['MSG_TEMPLATE']['NGAP']['NGSETUP'])
MSG_TEMPLATE_NGAP_INITUEMSG_REGISTRATION_REQUEST = binascii.unhexlify(cfg['MSG_TEMPLATE']['NGAP']['INITUEMSG_REGISTRATION_REQUEST'])
MSG_TEMPLATE_NGAP_UPLINKNASTRANSPORT_AUTH_RESPONSE = binascii.unhexlify(cfg['MSG_TEMPLATE']['NGAP']['UPLINKNASTRANSPORT_AUTH_RESPONSE'])
MSG_TEMPLATE_NGAP_UPLINKNASTRANSPORT_SECURITY_MODE_COMPLETE = binascii.unhexlify(cfg['MSG_TEMPLATE']['NGAP']['UPLINKNASTRANSPORT_SECURITY_MODE_COMPLETE'])
MSG_TEMPLATE_NGAP_UPLINKNASTRANSPORT_IDENTITY_RESPONSE = binascii.unhexlify(cfg['MSG_TEMPLATE']['NGAP']['UPLINKNASTRANSPORT_IDENTITY_RESPONSE'])
MSG_TEMPLATE_NGAP_UPLINKNASTRANSPORT_REGISTRATION_COMPLETE = binascii.unhexlify(cfg['MSG_TEMPLATE']['NGAP']['UPLINKNASTRANSPORT_REGISTRATION_COMPLETE'])
MSG_TEMPLATE_NGAP_UPLINKNASTRANSPORT_PDU_SESSION_EST_REQUEST = binascii.unhexlify(cfg['MSG_TEMPLATE']['NGAP']['UPLINKNASTRANSPORT_PDU_SESSION_EST_REQUEST'])
MSG_TEMPLATE_NGAP_INITIALCONTEXTSETUPRESPONSE = binascii.unhexlify(cfg['MSG_TEMPLATE']['NGAP']['INITIALCONTEXTSETUPRESPONSE'])
MSG_TEMPLATE_NGAP_UERADIOCAPABILITYINFOINDICATION = binascii.unhexlify(cfg['MSG_TEMPLATE']['NGAP']['UERADIOCAPABILITYINFOINDICATION'])
MSG_TEMPLATE_NGAP_UPLINKNASTRANSPORT_PDU_RELEASE_SESSION_REQUEST = binascii.unhexlify(cfg['MSG_TEMPLATE']['NGAP']['UPLINKNASTRANSPORT_PDU_RELEASE_SESSION_REQUEST'])
MSG_TEMPLATE_NGAP_UECONTEXTRELEASECOMPLETE = binascii.unhexlify(cfg['MSG_TEMPLATE']['NGAP']['UECONTEXTRELEASECOMPLETE'])
MSG_TEMPLATE_NGAP_PDUSESSIONRESOURCERELEASERESPONSE = binascii.unhexlify(cfg['MSG_TEMPLATE']['NGAP']['PDUSESSIONRESOURCERELEASERESPONSE'])
MSG_TEMPLATE_NGAP_UPLINKNASTRANSPORT_PDU_SESSION_RELEASE_COMPLETE = binascii.unhexlify(cfg['MSG_TEMPLATE']['NGAP']['UPLINKNASTRANSPORT_PDU_SESSION_RELEASE_COMPLETE'])
MSG_TEMPLATE_NGAP_UPLINKNASTRANSPORT_DEREGISTRATION_COMPLETE = binascii.unhexlify(cfg['MSG_TEMPLATE']['NGAP']['UPLINKNASTRANSPORT_DEREGISTRATION_COMPLETE'])

# 5GNAS
MSG_TEMPLATE_5GNAS_REGISTRATION_REQUEST = binascii.unhexlify(cfg['MSG_TEMPLATE']['NAS5G']['REGISTRATION_REQUEST'])
MSG_TEMPLATE_5GNAS_AUTH_RESPONSE = binascii.unhexlify(cfg['MSG_TEMPLATE']['NAS5G']['AUTH_RESPONSE'])
MSG_TEMPLATE_5GNAS_SECURITY_MODE_COMPLETE = binascii.unhexlify(cfg['MSG_TEMPLATE']['NAS5G']['SECURITY_MODE_COMPLETE'])
MSG_TEMPLATE_5GNAS_IDENTITY_RESPONSE = binascii.unhexlify(cfg['MSG_TEMPLATE']['NAS5G']['IDENTITY_RESPONSE'])
MSG_TEMPLATE_5GNAS_REGISTRATION_COMPLETE = binascii.unhexlify(cfg['MSG_TEMPLATE']['NAS5G']['REGISTRATION_COMPLETE'])
MSG_TEMPLATE_5GNAS_PDU_SESSION_EST_REQUEST = binascii.unhexlify(cfg['MSG_TEMPLATE']['NAS5G']['PDU_SESSION_EST_REQUEST'])
MSG_TEMPLATE_5GNAS_PDU_RELEASE_SESSION_REQUEST = binascii.unhexlify(cfg['MSG_TEMPLATE']['NAS5G']['PDU_RELEASE_SESSION_REQUEST'])
MSG_TEMPLATE_5GNAS_PDU_SESSION_RELEASE_COMPLETE = binascii.unhexlify(cfg['MSG_TEMPLATE']['NAS5G']['PDU_SESSION_RELEASE_COMPLETE'])
MSG_TEMPLATE_5GNAS_DEREGISTRATION_COMPLETE = binascii.unhexlify(cfg['MSG_TEMPLATE']['NAS5G']['DEREGISTRATION_COMPLETE'])
###MSG TEMPLATE###################

#Message authentication code: 0x00000000
MAC = binascii.unhexlify("00000000"); 

#############################
# initiatize global var 
ngap = NGAP.NGAP_PDU_Descriptions.NGAP_PDU
tac = cfg['main']['tac']
tacHex =  struct.pack(">i", tac)[1:4]
plmn_mcc = cfg['main']['plmn_mcc']
plmn_mnc = cfg['main']['plmn_mnc']
plmnHex = plmn_encode_f214365(plmn_mcc+plmn_mnc)
gNBId = cfg['main']['gNBId']
ran_ue_ngapId =  (random.randint(1, 4294967294))
nRCellIdentity = cfg['main']['nRCellIdentity']
imeisv = encode_bcd(cfg['subscriber']['imeisv'])
plmnHexSucif216354 = plmnHexSucif216354(plmn_mcc+plmn_mnc)
suci = binascii.unhexlify("000d01") + plmnHexSucif216354 + binascii.unhexlify(cfg['subscriber']['suciSuffix']) # 5GS mobile identity 000d-01-216354-000000000000001000
UserPlaneLocalTeidInt = 1
UserPlaneLocalTeid = struct.pack(">i",UserPlaneLocalTeidInt)
UserPlaneLocalIpaddr = cfg['userplane']['Ipaddr']
UserPlaneLocalIpaddrInt = ip2int(UserPlaneLocalIpaddr) 
UserPlanePort = cfg['userplane']['port']
UserPlaneIcmpDestIpaddr = cfg['userplane']['IcmpDestIpaddr']
UserPlaneIcmpUEIpaddr = "127.0.0.1"
#############################

#############################
# testname
def callp_testname(enb_sctp,gtpuserplane,out_queue,resturi,suci,restApi_start,nodelay,testname):
    testname = testname.lower() 
    if testname=="5gngsetup":
       callp_5gngsetup(enb_sctp,gtpuserplane,out_queue,resturi,restApi_start,nodelay)
    elif  testname=="5greg":
       callp_5greg(enb_sctp,gtpuserplane,out_queue,resturi,suci,restApi_start,nodelay)
    else:
      listsuccess = {testname:[{'result': 'path not supported'}]}  
      out_queue.put(listsuccess)
#############################
       

##################################
def callp_5gngsetup(enb_sctp,gtpuserplane,out_queue,resturi,restApi_start,nodelay):
  #############################
  # NGAP	NGSetupRequest
  logging.info(printSepChar()) 
  logging.info("NGSetupRequest")
  ngap_ngsetup_request_hex = MSG_TEMPLATE_NGAP_NGSETUP
  ngap.from_aper(ngap_ngsetup_request_hex)
  ngap_ngsetup_request = ngap.get_val()
  ngap_tAISliceSupportList_sNSSAI = []
  ngap_tAISliceSupportList_sNSSAI.append({'s-NSSAI':{'sST': b'\x01', 'sD': b'\xd1\x43\xa5'}})
  ngap_tAISliceSupportList_sNSSAI.append({'s-NSSAI':{'sST': b'\x02', 'sD': b'\xd1\x43\xa5'}})
  ngap_tAISliceSupportList_sNSSAI.append({'s-NSSAI':{'sST': b'\x03', 'sD': b'\xd1\x43\xa5'}})
  ngap_tAISliceSupportList_sNSSAI.append({'s-NSSAI':{'sST': b'\x10', 'sD': b'\xab\xcd\xef'}})
  #id-1
  ngap_ngsetup_request[1]['value'][1]['protocolIEs'][1]['value'][1][0]['broadcastPLMNList'][0]['tAISliceSupportList'] = (ngap_tAISliceSupportList_sNSSAI)
  ngap_ngsetup_request[1]['value'][1]['protocolIEs'][1]['value'][1][0]['broadcastPLMNList'][0]['pLMNIdentity'] = (plmnHex)
  ngap_ngsetup_request[1]['value'][1]['protocolIEs'][1]['value'][1][0]['tAC'] = (tacHex)
  #id-0
  ngap_ngsetup_request[1]['value'][1]['protocolIEs'][0]['value'][1][1]['gNB-ID'] = ('gNB-ID', (gNBId, 32))
  ngap_ngsetup_request[1]['value'][1]['protocolIEs'][0]['value'][1][1]['pLMNIdentity'] = (plmnHex)
  print("SEND--> " + ngap.to_asn1())
  ngap.set_val(ngap_ngsetup_request)
  enb_sctp.send(ngap.to_aper())
  #############################

  #############################
  # NGAP	NGSetupResponse
  ngap_ngsetup_response_hex = enb_sctp.recv(4096)
  ngap.from_aper(ngap_ngsetup_response_hex)
  ngap_ngsetup_response =ngap.to_asn1()
  print("<--RECV " + ngap_ngsetup_response)
  if 'successfulOutcome' in ngap_ngsetup_response:
       logging.info("NGSetupResponse")
       logging.info("gENB success setup to AMF.")
  else:
    failedcase()
  time.sleep(1)

  listsuccess ={resturi:[{'result': 'success'}]}
  out_queue.put(listsuccess)
###restapi_resource_5gngsetup#####

##################################
def callp_5greg(enb_sctp,gtpuserplane,out_queue,resturi,suci,restApi_start,nodelay):
  ngap = NGAP.NGAP_PDU_Descriptions.NGAP_PDU    
  #############################
  # NGAP/NAS-5GS	InitialUEMessage, Registration request
  logging.info(printSepChar()) 
  logging.info("InitialUEMessage Registration request")
  nas5G_registration_request_hex = MSG_TEMPLATE_5GNAS_REGISTRATION_REQUEST[0:4] + suci + MSG_TEMPLATE_5GNAS_REGISTRATION_REQUEST[19:]
  ngap_initialUEMessage_registration_request_hex = MSG_TEMPLATE_NGAP_INITUEMSG_REGISTRATION_REQUEST
  ngap.from_aper(ngap_initialUEMessage_registration_request_hex)
  ngap_initialUEMessage_registration_request = ngap.get_val()
  ngap_initialUEMessage_registration_request[1]['value'][1]['protocolIEs'][0]['value']  =  ('RAN-UE-NGAP-ID',ran_ue_ngapId) 
  ngap_initialUEMessage_registration_request[1]['value'][1]['protocolIEs'][1]['value']  =  ('NAS-PDU',nas5G_registration_request_hex)
  ngap_initialUEMessage_registration_request[1]['value'][1]['protocolIEs'][2]['value'][1][1]['nR-CGI'] = {'nRCellIdentity': (nRCellIdentity, 36), 'pLMNIdentity': plmnHex}
  ngap_initialUEMessage_registration_request[1]['value'][1]['protocolIEs'][2]['value'][1][1]['tAI'] = {'tAC': tacHex, 'pLMNIdentity': plmnHex}
  ngap_initialUEMessage_registration_request[1]['value'][1]['protocolIEs'][3]['value'] = ('RRCEstablishmentCause', 'mo-Signalling')
  ngap.set_val(ngap_initialUEMessage_registration_request)
  print("SEND--> " + ngap.to_asn1())
  enb_sctp.send(ngap.to_aper())
  #############################

  #############################
  # NGAP/NAS-5GS	DownlinkNASTransport, Authentication request
  ngap_downlinkNASTransport_authentication_request_hex = enb_sctp.recv(4096)
  ngap.from_aper(ngap_downlinkNASTransport_authentication_request_hex)
  ngap_downlinkNASTransport_authentication_request=ngap.to_asn1()
  print("<--RECV " + ngap_downlinkNASTransport_authentication_request)
  if 'DownlinkNASTransport' in ngap_downlinkNASTransport_authentication_request:
      rawmsg = ngap()  
      _ , nas5g_authentication_request =(rawmsg[1]['value'][1]['protocolIEs'][2]['value'])
      if nas5g_authentication_request[2:3] ==  binascii.unhexlify("56"):
        logging.info("DownlinkNASTransport, Authentication request")
      else:
        failedcase()    
  else:
    failedcase()
 
  # get amf id
  auth_request = ngap()
  _ , AMF_UE_NGAP_ID =(auth_request[1]['value'][1]['protocolIEs'][0]['value'])

  #kdf
  k = binascii.unhexlify("00000000000000000000000000000000")
  sn_id = binascii.unhexlify("00000000000000000000000000000000")
  snn = b'5G:mnc456.mcc123.3gppnetwork.org'
  rand = binascii.unhexlify("00000000000000000000000000000000")
  res = binascii.unhexlify("303E1DAF5C3D0FB5")
  resstar = conv_akaresStar(k,sn_id,rand,res)
  resstar = binascii.unhexlify("a35bf375d489f657d0db7b88959a1465")
  #############################

  time.sleep(0.05)

  #############################
  # NGAP/NAS-5GS	UplinkNASTransport, Authentication response
  logging.info("UplinkNASTransport, Authentication response")
  nas5G_Authentication_response_hex = MSG_TEMPLATE_5GNAS_AUTH_RESPONSE[0:5] + resstar 
  ngap_uplinkNASTransport_authentication_response_hex = MSG_TEMPLATE_NGAP_UPLINKNASTRANSPORT_AUTH_RESPONSE
  ngap.from_aper(ngap_uplinkNASTransport_authentication_response_hex)
  ngap_uplinkNASTransport_authentication_response = ngap.get_val()
  ngap_uplinkNASTransport_authentication_response[1]['value'][1]['protocolIEs'][0]['value']  =  ('AMF-UE-NGAP-ID', AMF_UE_NGAP_ID)
  ngap_uplinkNASTransport_authentication_response[1]['value'][1]['protocolIEs'][1]['value']  =  ('RAN-UE-NGAP-ID',ran_ue_ngapId) 
  ngap_uplinkNASTransport_authentication_response[1]['value'][1]['protocolIEs'][2]['value']  =  ('NAS-PDU',nas5G_Authentication_response_hex)
  ngap_uplinkNASTransport_authentication_response[1]['value'][1]['protocolIEs'][3]['value'][1][1]['nR-CGI'] = {'nRCellIdentity': (nRCellIdentity, 36), 'pLMNIdentity': plmnHex}
  ngap_uplinkNASTransport_authentication_response[1]['value'][1]['protocolIEs'][3]['value'][1][1]['tAI'] = {'tAC': tacHex, 'pLMNIdentity': plmnHex}
  ngap.set_val(ngap_uplinkNASTransport_authentication_response)
  print("SEND--> " + ngap.to_asn1())
  enb_sctp.send(ngap.to_aper())
  #############################

  #############################
  #	NGAP/NAS-5GS	DownlinkNASTransport, Security mode command
  ngap_downlinkNASTransport_securitymode_command_hex = enb_sctp.recv(4096)
  ngap.from_aper(ngap_downlinkNASTransport_securitymode_command_hex)
  ngap_downlinkNASTransport_securitymode_command = ngap.to_asn1()
  print("<--RECV " + ngap_downlinkNASTransport_securitymode_command)
  if 'DownlinkNASTransport' in ngap_downlinkNASTransport_securitymode_command:
      rawmsg = ngap()  
      _ , nas5g_securitymode_command =(rawmsg[1]['value'][1]['protocolIEs'][2]['value'])
      if nas5g_securitymode_command[9:10] ==  binascii.unhexlify("5d"):
        logging.info("DownlinkNASTransport, Security mode command")
      else:
        failedcase()
  else:
    failedcase()
  #############################

  time.sleep(0.05)

  #############################
  # NGAP/NAS-5GS	UplinkNASTransport, Security mode complete
  logging.info("UplinkNASTransport, Security mode complete")
  nas_SMC = MSG_TEMPLATE_5GNAS_SECURITY_MODE_COMPLETE
  nas_SMC = nas_SMC[0:2] + MAC + nas_SMC[6:]   
  ngap_uplinkNASTransport_security_mode_complete_hex = MSG_TEMPLATE_NGAP_UPLINKNASTRANSPORT_SECURITY_MODE_COMPLETE
  ngap.from_aper(ngap_uplinkNASTransport_security_mode_complete_hex)
  ngap_uplinkNASTransport_security_mode_complete = ngap.get_val()
  ngap_uplinkNASTransport_security_mode_complete[1]['value'][1]['protocolIEs'][0]['value']  =  ('AMF-UE-NGAP-ID', AMF_UE_NGAP_ID)
  ngap_uplinkNASTransport_security_mode_complete[1]['value'][1]['protocolIEs'][1]['value']  =  ('RAN-UE-NGAP-ID',ran_ue_ngapId) 
  ngap_uplinkNASTransport_security_mode_complete[1]['value'][1]['protocolIEs'][2]['value']  =  ('NAS-PDU',nas_SMC)
  ngap_uplinkNASTransport_security_mode_complete[1]['value'][1]['protocolIEs'][3]['value'][1][1]['nR-CGI'] = {'nRCellIdentity': (nRCellIdentity, 36), 'pLMNIdentity': plmnHex}
  ngap_uplinkNASTransport_security_mode_complete[1]['value'][1]['protocolIEs'][3]['value'][1][1]['tAI'] = {'tAC': tacHex, 'pLMNIdentity': plmnHex}
  ngap.set_val(ngap_uplinkNASTransport_security_mode_complete)
  print("SEND--> " + ngap.to_asn1())
  enb_sctp.send(ngap.to_aper())
  #############################

  #############################
  # NGAP/NAS-5GS	DownlinkNASTransport, Identity request
  ngap_downlinkNASTransport_identity_request_hex = enb_sctp.recv(4096)
  ngap.from_aper(ngap_downlinkNASTransport_identity_request_hex)
  ngap_downlinkNASTransport_identity_request = ngap.to_asn1()
  print("<--RECV " + ngap_downlinkNASTransport_identity_request)
  if 'DownlinkNASTransport' in ngap_downlinkNASTransport_identity_request:
      rawmsg = ngap()  
      _ , nas5g_Identity_request =(rawmsg[1]['value'][1]['protocolIEs'][2]['value'])
      if nas5g_Identity_request[9:10] ==  binascii.unhexlify("5b"):
        logging.info("DownlinkNASTransport, Identity request")
      else:
        failedcase()
  else:
    failedcase()
  #############################

  time.sleep(0.05)
  
  #############################
  # NGAP/NAS-5GS	UplinkNASTransport, Identity response
  logging.info("UplinkNASTransport,  Identity response")
  nas_IDS = MSG_TEMPLATE_5GNAS_IDENTITY_RESPONSE
  nas_IDS = nas_IDS[0:2] + MAC + nas_IDS[6:13] + imeisv 
  ngap_uplinkNASTransport_identity_response_hex = MSG_TEMPLATE_NGAP_UPLINKNASTRANSPORT_IDENTITY_RESPONSE
  ngap.from_aper(ngap_uplinkNASTransport_identity_response_hex)
  ngap_uplinkNASTransport_identity_response = ngap.get_val()
  ngap_uplinkNASTransport_identity_response[1]['value'][1]['protocolIEs'][0]['value']  =  ('AMF-UE-NGAP-ID', AMF_UE_NGAP_ID)
  ngap_uplinkNASTransport_identity_response[1]['value'][1]['protocolIEs'][1]['value']  =  ('RAN-UE-NGAP-ID',ran_ue_ngapId) 
  ngap_uplinkNASTransport_identity_response[1]['value'][1]['protocolIEs'][2]['value']  =  ('NAS-PDU',nas_IDS)
  ngap_uplinkNASTransport_identity_response[1]['value'][1]['protocolIEs'][3]['value'][1][1]['nR-CGI'] = {'nRCellIdentity': (nRCellIdentity, 36), 'pLMNIdentity': plmnHex}
  ngap_uplinkNASTransport_identity_response[1]['value'][1]['protocolIEs'][3]['value'][1][1]['tAI'] = {'tAC': tacHex, 'pLMNIdentity': plmnHex}
  ngap.set_val(ngap_uplinkNASTransport_identity_response)
  print("SEND--> " + ngap.to_asn1())
  enb_sctp.send(ngap.to_aper())
  #############################

  #############################
  # NGAP/NAS-5GS	DownlinkNASTransport, Registration accept
  ngap_downlinkNASTransport_registration_accept_hex = enb_sctp.recv(4096)
  ngap.from_aper(ngap_downlinkNASTransport_registration_accept_hex)
  ngap_downlinkNASTransport_registration_accept = ngap.to_asn1()
  print("<--RECV " + ngap_downlinkNASTransport_registration_accept)
  if 'DownlinkNASTransport' in ngap_downlinkNASTransport_registration_accept:
      rawmsg = ngap()  
      _ , nas5g_Identity_request =(rawmsg[1]['value'][1]['protocolIEs'][2]['value'])
      if nas5g_Identity_request[9:10] ==  binascii.unhexlify("42"):
        logging.info("DownlinkNASTransport, Registration accept")
      else:
        failedcase()
  else:
    failedcase()
  #############################

  # get 5G guti
  mobile_identity_GUTI = nas5g_Identity_request[13:26]

  time.sleep(0.05)

  #############################
  # NGAP/NAS-5GS	UplinkNASTransport, Registration complete
  logging.info("UplinkNASTransport,  Registration complete")
  nas_RGC = MSG_TEMPLATE_5GNAS_REGISTRATION_COMPLETE
  nas_RGC = nas_RGC[0:2] + MAC + nas_RGC[6:]   
  ngap_uplinkNASTransport_registration_complete_hex = MSG_TEMPLATE_NGAP_UPLINKNASTRANSPORT_REGISTRATION_COMPLETE
  ngap.from_aper(ngap_uplinkNASTransport_registration_complete_hex)
  ngap_uplinkNASTransport_registration_complete = ngap.get_val()
  ngap_uplinkNASTransport_registration_complete[1]['value'][1]['protocolIEs'][0]['value']  =  ('AMF-UE-NGAP-ID', AMF_UE_NGAP_ID)
  ngap_uplinkNASTransport_registration_complete[1]['value'][1]['protocolIEs'][1]['value']  =  ('RAN-UE-NGAP-ID',ran_ue_ngapId) 
  ngap_uplinkNASTransport_registration_complete[1]['value'][1]['protocolIEs'][2]['value']  =  ('NAS-PDU',nas_RGC)
  ngap_uplinkNASTransport_registration_complete[1]['value'][1]['protocolIEs'][3]['value'][1][1]['nR-CGI'] = {'nRCellIdentity': (nRCellIdentity, 36), 'pLMNIdentity': plmnHex}
  ngap_uplinkNASTransport_registration_complete[1]['value'][1]['protocolIEs'][3]['value'][1][1]['tAI'] = {'tAC': tacHex, 'pLMNIdentity': plmnHex}
  ngap.set_val(ngap_uplinkNASTransport_registration_complete)
  print("SEND--> " + ngap.to_asn1())
  enb_sctp.send(ngap.to_aper())
  #############################
  
  #############################
  # NGAP/NAS-5GS	DownlinkNASTransport, Configuration update command
  ngap_downlinkNASTransport_configuration_update_command_hex = enb_sctp.recv(4096)
  ngap.from_aper(ngap_downlinkNASTransport_configuration_update_command_hex)
  ngap_downlinkNASTransport_configuration_update_command = ngap.to_asn1()
  print("<--RECV " + ngap_downlinkNASTransport_configuration_update_command)
  if 'DownlinkNASTransport' in ngap_downlinkNASTransport_configuration_update_command:
      rawmsg = ngap()  
      _ , nas5g_configuration_update_command =(rawmsg[1]['value'][1]['protocolIEs'][2]['value'])
      if nas5g_configuration_update_command[9:10] ==  binascii.unhexlify("54"):
        logging.info("DownlinkNASTransport, Configuration update command")
      else:
        failedcase()
  else:
    failedcase()
  #############################

  time.sleep(1)

  #############################
  #	NGAP/NAS-5GS	UplinkNASTransport, UL NAS transport, PDU session establishment request	
  logging.info("UplinkNASTransport, UL NAS transport, PDU session establishment request	")
  nas_PDU_sNSSA= binascii.unhexlify("0aabcdef") 
  nas_PDU_sNSSA= binascii.unhexlify("01D143A5") 
  nas_PDU_ER = MSG_TEMPLATE_5GNAS_PDU_SESSION_EST_REQUEST
  nas_PDU_ER = nas_PDU_ER[0:28]  + nas_PDU_sNSSA + nas_PDU_ER[32:] 
  nas_PDU_ER = nas_PDU_ER[0:2] + MAC + nas_PDU_ER[6:]   
  ngap_uplinkNASTransport_pdu_session_establishment_request_hex = MSG_TEMPLATE_NGAP_UPLINKNASTRANSPORT_PDU_SESSION_EST_REQUEST
  ngap.from_aper(ngap_uplinkNASTransport_pdu_session_establishment_request_hex)
  ngap_uplinkNASTransport_pdu_session_establishment_request = ngap.get_val()
  ngap_uplinkNASTransport_pdu_session_establishment_request[1]['value'][1]['protocolIEs'][0]['value']  =  ('AMF-UE-NGAP-ID', AMF_UE_NGAP_ID)
  ngap_uplinkNASTransport_pdu_session_establishment_request[1]['value'][1]['protocolIEs'][1]['value']  =  ('RAN-UE-NGAP-ID',ran_ue_ngapId) 
  ngap_uplinkNASTransport_pdu_session_establishment_request[1]['value'][1]['protocolIEs'][2]['value']  =  ('NAS-PDU',nas_PDU_ER)
  ngap_uplinkNASTransport_pdu_session_establishment_request[1]['value'][1]['protocolIEs'][3]['value'][1][1]['nR-CGI'] = {'nRCellIdentity': (nRCellIdentity, 36), 'pLMNIdentity': plmnHex}
  ngap_uplinkNASTransport_pdu_session_establishment_request[1]['value'][1]['protocolIEs'][3]['value'][1][1]['tAI'] = {'tAC': tacHex, 'pLMNIdentity': plmnHex}
  ngap.set_val(ngap_uplinkNASTransport_pdu_session_establishment_request)
  print("SEND--> " + ngap.to_asn1())
  logging.info("UplinkNASTransport, UL NAS transport, PDU session establishment request")
  enb_sctp.send(ngap.to_aper())
  #############################
    
  #############################
  # RECV: NGAP/NAS-5GS InitialContextSetupRequest, DL NAS transport, PDU session establishment accept
  ngap_initialCtx_pdu_session_establishment_accept_hex = enb_sctp.recv(4096)
  ngap.from_aper(ngap_initialCtx_pdu_session_establishment_accept_hex)
  ngap_initialCtx_pdu_session_establishment_accept= ngap.to_asn1()
  print("<--RECV " + ngap_initialCtx_pdu_session_establishment_accept)
  if 'InitialContextSetupRequest' in ngap_initialCtx_pdu_session_establishment_accept:
    pdu_session_accept = ngap()
    PDUSessionResourceSetupListCxtReq=(pdu_session_accept[1]['value'][1]['protocolIEs'][3]['value'])
    remote_gTP_TEID=PDUSessionResourceSetupListCxtReq[1][0]['pDUSessionResourceSetupRequestTransfer'][1]['protocolIEs'][0]['value'][1][1]['gTP-TEID']
    remote_transportLayerAddressInt, _= PDUSessionResourceSetupListCxtReq[1][0]['pDUSessionResourceSetupRequestTransfer'][1]['protocolIEs'][0]['value'][1][1]['transportLayerAddress']
    UserPlaneRemoteTeid = struct.unpack(">i", remote_gTP_TEID)[0]
    UserPlaneRemoteIpaddr = int2ip(remote_transportLayerAddressInt)
    nas_pdu_session_establishment_accept = PDUSessionResourceSetupListCxtReq=(pdu_session_accept[1]['value'][1]['protocolIEs'][9]['value'][1]) # 'NAS-PDU'
    logging.info("InitialContextSetupRequest, DL NAS transport, PDU session establishment accept")
    #7e0200000000047e006801001c2e0101c21304646e6e320009716f735f72756c6531060001020304051201
  else:
    failedcase()
  #############################
 
  #############################
  # SEND: NGAP	InitialContextSetupResponse
  logging.info("InitialContextSetupResponse")
  pDUSessionResourceSetupResponseTransfer= {u'pDUSessionResourceSetupResponseTransfer': ('PDUSessionResourceSetupResponseTransfer', {u'qosFlowPerTNLInformation': {u'associatedQosFlowList': [{u'qosFlowIdentifier': 5}, {u'qosFlowIdentifier': 6}], u'uPTransportLayerInformation': (u'gTPTunnel', {u'gTP-TEID': UserPlaneLocalTeid, u'transportLayerAddress': (UserPlaneLocalIpaddrInt, 32)})}}), u'pDUSessionID': 1}
  ngap_InitialContextSetupResponse_hex = MSG_TEMPLATE_NGAP_INITIALCONTEXTSETUPRESPONSE
  ngap.from_aper(ngap_InitialContextSetupResponse_hex)
  ngap_InitialContextSetupResponse = ngap.get_val()
  ngap_InitialContextSetupResponse[1]['value'][1]['protocolIEs'][0]['value']  =  ('AMF-UE-NGAP-ID', AMF_UE_NGAP_ID)
  ngap_InitialContextSetupResponse[1]['value'][1]['protocolIEs'][1]['value']  =  ('RAN-UE-NGAP-ID', ran_ue_ngapId) 
  ngap_InitialContextSetupResponse[1]['value'][1]['protocolIEs'][2]['value'][1][0] = pDUSessionResourceSetupResponseTransfer
  ngap.set_val(ngap_InitialContextSetupResponse)
  print("SEND--> " + ngap.to_asn1())
  enb_sctp.send(ngap.to_aper())
  #############################

  time.sleep(0.50)

  #############################
  # SEND: NGAP	UERadioCapabilityInfoIndication
  logging.info("UERadioCapabilityInfoIndication")
  ngap_UERadioCapabilityInfoIndication_hex = MSG_TEMPLATE_NGAP_UERADIOCAPABILITYINFOINDICATION
  ngap.from_aper(ngap_UERadioCapabilityInfoIndication_hex)
  ngap_UERadioCapabilityInfoIndication = ngap.get_val()
  ngap_UERadioCapabilityInfoIndication[1]['value'][1]['protocolIEs'][0]['value']  =  ('AMF-UE-NGAP-ID', AMF_UE_NGAP_ID)
  ngap_UERadioCapabilityInfoIndication[1]['value'][1]['protocolIEs'][1]['value']  =  ('RAN-UE-NGAP-ID', ran_ue_ngapId) 
  ngap.set_val(ngap_UERadioCapabilityInfoIndication)
  print("SEND--> " + ngap.to_asn1())
  enb_sctp.send(ngap.to_aper())
  #############################

  #############################
  # gtpu start
  logging.info(printSepChar()) 
  gtpuserplane.StartGtpu(UserPlaneRemoteIpaddr,UserPlaneRemoteTeid,UserPlaneIcmpUEIpaddr,UserPlaneIcmpDestIpaddr) 
  
  #############################

  logging.info("success,PDU session establishment accept")
  if restApi_start == False:
    if nodelay == False:
      logging.info("Press any key to continue, Deregistration request: ") 
      print(input(""))
  logging.info(printSepChar()) 
  
  time.sleep(1)
 
  #############################
  # NGAP/NAS-5GS	UplinkNASTransport, PDU session release request 
  logging.info("UplinkNASTransport, PDU session release request")
  nas_PDU_RR = MSG_TEMPLATE_5GNAS_PDU_RELEASE_SESSION_REQUEST
  nas_PDU_RR = nas_PDU_RR[0:2] + MAC + nas_PDU_RR[6:]   
  ngap_uplinkNASTransport_pdu_session_release_request_hex = MSG_TEMPLATE_NGAP_UPLINKNASTRANSPORT_PDU_RELEASE_SESSION_REQUEST
  ngap.from_aper(ngap_uplinkNASTransport_pdu_session_release_request_hex)
  ngap_uplinkNASTransport_pdu_session_release_request = ngap.get_val()
  ngap_uplinkNASTransport_pdu_session_release_request[1]['value'][1]['protocolIEs'][0]['value']  =  ('AMF-UE-NGAP-ID', AMF_UE_NGAP_ID)
  ngap_uplinkNASTransport_pdu_session_release_request[1]['value'][1]['protocolIEs'][1]['value']  =  ('RAN-UE-NGAP-ID',ran_ue_ngapId) 
  ngap_uplinkNASTransport_pdu_session_release_request[1]['value'][1]['protocolIEs'][2]['value']  =  ('NAS-PDU',nas_PDU_RR)
  ngap_uplinkNASTransport_pdu_session_release_request[1]['value'][1]['protocolIEs'][3]['value'][1][1]['nR-CGI'] = {'nRCellIdentity': (nRCellIdentity, 36), 'pLMNIdentity': plmnHex}
  ngap_uplinkNASTransport_pdu_session_release_request[1]['value'][1]['protocolIEs'][3]['value'][1][1]['tAI'] = {'tAC': tacHex, 'pLMNIdentity': plmnHex}
  ngap.set_val(ngap_uplinkNASTransport_pdu_session_release_request)
  print("SEND--> " + ngap.to_asn1())
  enb_sctp.send(ngap.to_aper())
  #############################

  #############################
  # NGAP/NAS-5GS	PDUSessionResourceReleaseCommand, DL NAS transport, PDU session release command (Regular deactivation)
  ngap_PDUSessionResourceReleaseCommand_hex = enb_sctp.recv(4096)
  ngap.from_aper(ngap_PDUSessionResourceReleaseCommand_hex)
  ngap_PDUSessionResourceReleaseCommand=ngap.to_asn1()
  print("<--RECV " + ngap_PDUSessionResourceReleaseCommand)
  if 'PDUSessionResourceReleaseCommand' in ngap_PDUSessionResourceReleaseCommand:
      logging.info("PDUSessionResourceReleaseCommand")
  else:
    failedcase()
  #############################

  time.sleep(0.05)

  #############################
  # SEND: NGAP	PDUSessionResourceReleaseResponse
  logging.info("PDUSessionResourceReleaseResponse")
  ngap_PDUSessionResourceReleaseResponse_hex = MSG_TEMPLATE_NGAP_PDUSESSIONRESOURCERELEASERESPONSE
  ngap.from_aper(ngap_PDUSessionResourceReleaseResponse_hex)
  ngap_PDUSessionResourceReleaseResponse = ngap.get_val()
  ngap_PDUSessionResourceReleaseResponse[1]['value'][1]['protocolIEs'][0]['value']  =  ('AMF-UE-NGAP-ID', AMF_UE_NGAP_ID)
  ngap_PDUSessionResourceReleaseResponse[1]['value'][1]['protocolIEs'][1]['value']  =  ('RAN-UE-NGAP-ID', ran_ue_ngapId) 
  ngap.set_val(ngap_PDUSessionResourceReleaseResponse)
  print("SEND--> " + ngap.to_asn1())
  enb_sctp.send(ngap.to_aper())
  #############################

  time.sleep(0.05)

  #############################
  # NGAP/NAS-5GS	UplinkNASTransport, UL NAS transport, PDU session release complete 
  logging.info("UplinkNASTransport, UL NAS transport, PDU session release complete")
  nas_PDU_RC = MSG_TEMPLATE_5GNAS_PDU_SESSION_RELEASE_COMPLETE
  nas_PDU_RC = nas_PDU_RC[0:2] + MAC + nas_PDU_RC[6:]   
  ngap_uplinkNASTransport_pdu_session_release_complete_hex =  MSG_TEMPLATE_NGAP_UPLINKNASTRANSPORT_PDU_SESSION_RELEASE_COMPLETE
  ngap.from_aper(ngap_uplinkNASTransport_pdu_session_release_complete_hex)
  ngap_uplinkNASTransport_pdu_session_release_complete = ngap.get_val()
  ngap_uplinkNASTransport_pdu_session_release_complete[1]['value'][1]['protocolIEs'][0]['value']  =  ('AMF-UE-NGAP-ID', AMF_UE_NGAP_ID)
  ngap_uplinkNASTransport_pdu_session_release_complete[1]['value'][1]['protocolIEs'][1]['value']  =  ('RAN-UE-NGAP-ID',ran_ue_ngapId) 
  ngap_uplinkNASTransport_pdu_session_release_complete[1]['value'][1]['protocolIEs'][2]['value']  =  ('NAS-PDU',nas_PDU_RC)
  ngap_uplinkNASTransport_pdu_session_release_complete[1]['value'][1]['protocolIEs'][3]['value'][1][1]['nR-CGI'] = {'nRCellIdentity': (nRCellIdentity, 36), 'pLMNIdentity': plmnHex}
  ngap_uplinkNASTransport_pdu_session_release_complete[1]['value'][1]['protocolIEs'][3]['value'][1][1]['tAI'] = {'tAC': tacHex, 'pLMNIdentity': plmnHex}
  ngap.set_val(ngap_uplinkNASTransport_pdu_session_release_complete)
  print("SEND--> " + ngap.to_asn1())
  enb_sctp.send(ngap.to_aper())
  #############################
 
  time.sleep(2)

  #############################
  # NGAP/NAS-5GS	UplinkNASTransport, Deregistration request (UE originating)
  logging.info("UplinkNASTransport Deregistration request (UE originating)")
  nas_DER = MSG_TEMPLATE_5GNAS_DEREGISTRATION_COMPLETE
  nas_DER = nas_DER[0:11] + mobile_identity_GUTI
  nas_DER = nas_DER[0:2] + MAC + nas_DER[6:]   
  ngap_uplinkNASTransport_deregistration_request_hex = MSG_TEMPLATE_NGAP_UPLINKNASTRANSPORT_DEREGISTRATION_COMPLETE
  ngap.from_aper(ngap_uplinkNASTransport_deregistration_request_hex)
  ngap_uplinkNASTransport_deregistration_request = ngap.get_val()
  ngap_uplinkNASTransport_deregistration_request[1]['value'][1]['protocolIEs'][0]['value']  =  ('AMF-UE-NGAP-ID', AMF_UE_NGAP_ID)
  ngap_uplinkNASTransport_deregistration_request[1]['value'][1]['protocolIEs'][1]['value']  =  ('RAN-UE-NGAP-ID',ran_ue_ngapId) 
  ngap_uplinkNASTransport_deregistration_request[1]['value'][1]['protocolIEs'][2]['value']  =  ('NAS-PDU',nas_DER)
  ngap_uplinkNASTransport_deregistration_request[1]['value'][1]['protocolIEs'][3]['value'][1][1]['nR-CGI'] = {'nRCellIdentity': (nRCellIdentity, 36), 'pLMNIdentity': plmnHex}
  ngap_uplinkNASTransport_deregistration_request[1]['value'][1]['protocolIEs'][3]['value'][1][1]['tAI'] = {'tAC': tacHex, 'pLMNIdentity': plmnHex}
  ngap.set_val(ngap_uplinkNASTransport_deregistration_request)
  print("SEND--> " + ngap.to_asn1())
  enb_sctp.send(ngap.to_aper())
  #############################

  #############################
  # NGAP/NAS-5GS	DownlinkNASTransport, Deregistration accept (UE originating)
  ngap_downlinkNASTransport_deregistration_accept_hex = enb_sctp.recv(4096)
  ngap.from_aper(ngap_downlinkNASTransport_deregistration_accept_hex)
  ngap_downlinkNASTransport_deregistration_accept=ngap.to_asn1()
  print("<--RECV " + ngap_downlinkNASTransport_deregistration_accept)
  if 'DownlinkNASTransport' in ngap_downlinkNASTransport_deregistration_accept:
      rawmsg = ngap()  
      _ , nas5g_Deregistration_accept =(rawmsg[1]['value'][1]['protocolIEs'][2]['value'])
      if nas5g_Deregistration_accept[9:10] ==  binascii.unhexlify("46"):
        logging.info("DownlinkNASTransport, Deregistration accept (UE originating)")
      else:
        failedcase()
  else:
    failedcase()
  #############################

  #############################
  # NGAP	UEContextReleaseCommand
  ngap_UEContextReleaseCommand_hex = enb_sctp.recv(4096)
  ngap.from_aper(ngap_UEContextReleaseCommand_hex)
  ngap_UEContextReleaseCommand = ngap.to_asn1()
  print("<--RECV " + ngap_UEContextReleaseCommand)
  #############################

  time.sleep(0.05)

  #############################
  # NGAP	UEContextReleaseComplete
  logging.info("UEContextReleaseComplete")
  ngap_UEContextReleaseComplete_hex = MSG_TEMPLATE_NGAP_UECONTEXTRELEASECOMPLETE
  ngap.from_aper(ngap_UEContextReleaseComplete_hex)
  ngap_UEContextReleaseComplete = ngap.get_val()
  ngap_UEContextReleaseComplete[1]['value'][1]['protocolIEs'][0]['value']  =  ('AMF-UE-NGAP-ID', AMF_UE_NGAP_ID)
  ngap_UEContextReleaseComplete[1]['value'][1]['protocolIEs'][1]['value']  =  ('RAN-UE-NGAP-ID',ran_ue_ngapId) 
  ngap.set_val(ngap_UEContextReleaseComplete)
  print("SEND--> " + ngap.to_asn1())
  enb_sctp.send(ngap.to_aper())
  #############################
  
  #############################
  time.sleep(2)
  #enb_sctp.close()
  #############################

  listsuccess ={resturi:[{'result': 'success'}]}   
  out_queue.put(listsuccess)
####restapi_resource_5greg########



