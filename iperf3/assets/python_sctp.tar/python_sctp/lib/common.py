# -*- coding: UTF-8 -*-
#!/usr/bin/env python
# common
# vpavesi april 2019

##################################
import os, sys
import logging
import socket
import struct
import binascii
import inspect
import hmac
from hashlib import sha256
from Crypto.Cipher import AES
##################################

##################################
def printSepChar():
		nChar = str
		nChar = ('_' * 40 )
		return nChar	
####printSepChar##################

##################################
def totheend():
  logging.info(printSepChar())
  logging.info('success complete!')
  sys.exit(0)

def failedcase():
  logging.info(printSepChar())
  logging.info('failed!')
  sys.exit(1)
####totheend######################

##################################
def catchExceptionAppl(getErrorEx):
        #"Automatically log the current function details."
        # Get the previous frame in the stack, otherwise it would
        # be this function!!!
        func = inspect.currentframe().f_back.f_code

        # Dump the message + the name of this function to the log.
        logging.debug("%s: %s in %s:%i" % (
                getErrorEx,
                func.co_name,
                func.co_filename,
                func.co_firstlineno
        ))
###catchExceptionAppl#############


##################################
def kdf( K, S ):
    return hmac.new( K, S, sha256 ).digest()

def conv_akaresStar(k, snn, rand,res):
    """
    A.4 RES* and XRES* derivation function
    When deriving RES* from RES, RAND, and serving network name in the UE and when deriving XRES* from XRES,
    RAND, and the serving network name in the ARPF, the following parameters shall be used to form
    the input S to the KDF.
    - FC = 0x6B,
    - P0 = serving network name,
    - L0 = length of the serving network name ( variable length as specified in 24.501 [35]),
    - P1 = RAND,
    - L1 = length of RAND (i.e. 0x00 0x10) ,
    - P2 = RES or XRES,
    - L2 = length RES or XRES (i.e. variable length between 0x00 0x04 and 0x00 0x10) 
    """
    return kdf(k, b'\x6B' + snn + b'\0\x20' + rand + b'\0\x10' + res + b'\0\x10')
##################################    

##################################
def encode_bcd(dig):
    if len(dig) % 2:
        dig += 'F'
    dig = list(dig)
    dig[1::2], dig[::2] = dig[::2], dig[1::2]
    return binascii.unhexlify(''.join(dig))
####encode_bcd####################

##################################
def ip2int(addr):
    return struct.unpack("!I", socket.inet_aton(addr))[0]

def int2ip(addr):
    return socket.inet_ntoa(struct.pack("!I", addr))
####ip2int########################

##################################
# PLMN format 214365
def plmn_encode_f214365(dig):
  if len(dig) == 5:
    dig = dig + "f"
  plmn_214365 = binascii.unhexlify( dig[1:2] + dig[0:1] + dig[3:4] + dig[2:3] +  dig[5:6] + dig[4:5] )
  return plmn_214365

def plmnHexSucif216354(dig):
  if len(dig) == 5:
    dig = dig + "0"
  plmn_123645 = binascii.unhexlify( dig[1:2] + dig[0:1] + dig[5:6] + dig[2:3] +  dig[4:5] + dig[3:4] )
  return plmn_123645
####plmn_encode_f214365###########
