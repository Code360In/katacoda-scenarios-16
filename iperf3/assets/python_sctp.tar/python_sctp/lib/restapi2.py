# -*- coding: UTF-8 -*-
#!/usr/bin/env python
# restApi
# vpavesi april 2019

##################################
import os, sys
import logging
import socket
import h2.connection
import h2.events
import h2.config
import json
import binascii
import threading
from lib.callp import *
        
# py2-3
try:  
  from Queue import Queue
except ImportError:
  from queue import Queue
##################################
      
##################################
# py2 http2 restapi
def http2restapi2(enb_sctp,gtpuserplane,restapi_ipaddr,restapi_port):

  def send_response(conn, event,result):
    stream_id = event.stream_id
    response_data = json.dumps(result).encode('utf-8')

    conn.send_headers(
        stream_id=stream_id,
        headers=[
            (':status', '200'),
            ('server', '5GgENBrestApi/1.0'),
            ('content-length', str(len(response_data))),
            ('content-type', 'application/json'),
        ],
    )
    conn.send_data(
        stream_id=stream_id,
        data=response_data,
        end_stream=True
    )    

  def handle(sock):
    if (sys.version_info > (3, 0)):
      config = h2.config.H2Configuration() #client_side=False
      conn = h2.connection.H2Connection()
      conn.update_settings( 
                {h2.settings.SettingCodes.ENABLE_PUSH: 1}
      )
    else:
      config = h2.config.H2Configuration(client_side=False) #client_side=False
      conn = h2.connection.H2Connection(config=config)
      conn.update_settings( 
                {h2.settings.SettingCodes.ENABLE_PUSH: 0}
      )  
    sock.sendall(conn.data_to_send())

    while True:
        data = sock.recv(65535)
        if not data:
            break

        try:
           events = conn.receive_data(data)
           print(events)
           for event in events:
             if isinstance(event, h2.events.RequestReceived):
                headers = dict(event.headers)  # Invalid conversion, fix later.
                #assert headers[':method'] == b'GET'
                logging.info(headers)
                path = headers[':path'].lower()
                ####### api start
                if "5greg" in path:
                      resturi = "5greg"
                      try:
                        #5greg/suci/000d-01-216354-000000000000001000
                        suciurip = (path).split('/')[3]
                        suciuripsuf = suciurip.replace("-", "") 
                        sucirestapi = binascii.unhexlify(suciuripsuf)  # 5GS mobile identity 000d-01-216354-000000000000001000
                        restapiqueue = Queue()
                        threadRestApi5greg = threading.Thread(target = callp_5greg(enb_sctp,gtpuserplane,restapiqueue,resturi,sucirestapi,True,False))
                        threadRestApi5greg.daemon = True
                        threadRestApi5greg.start()
                        threadRestApi5greg.join()
                        result = restapiqueue.get(False)
                        logging.info(result)
                        send_response(conn, event,result)
                      except:   
                        listfail ={resturi:[{'result': 'failed'}]}                  
                        send_response(conn, event,listfail)
                      
                elif "5gngsetup" in path:
                    restapiqueue = Queue()
                    try:
                      resturi = "5gngsetup"
                      threadRestApi5gngsetup = threading.Thread(target = callp_5gngsetup(enb_sctp,gtpuserplane,restapiqueue,resturi,True,False))
                      threadRestApi5gngsetup.daemon = True
                      threadRestApi5gngsetup.join()
                      result = restapiqueue.get(False)
                      logging.info(result)
                      send_response(conn, event,result)
                    except:   
                     listfail = {resturi:[{'result': 'failed'}]}                  
                     send_response(conn, event,listfail)

                else:
                  listfail = {path:[{'result': 'path not supported'}]}                  
                  send_response(conn, event,listfail)     
                ####### api end.
         
        except KeyboardInterrupt:
          print("cade")
          sys.exit()
   
        except Exception as inst:
          logging.debug("%s",inst.args)
          continue

        data_to_send = conn.data_to_send()
        if data_to_send:
          sock.sendall(data_to_send)

  sock = socket.socket()
  sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
  sock.bind((restapi_ipaddr, restapi_port))
  sock.listen(5)

  while True:
    try:
      handle(sock.accept()[0])
    except KeyboardInterrupt:
      sys.exit(1)
    except Exception as inst:
      logging.debug("%s",inst.args)
#
##################################
