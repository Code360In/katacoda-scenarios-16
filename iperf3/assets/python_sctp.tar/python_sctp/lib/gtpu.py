# -*- coding: UTF-8 -*-
#!/usr/bin/env python
# gtpu
# vpavesi april 2019

##################################
import logging
import socket
import struct
import binascii
##################################

##################################
# initiaze
##################################

##################################
class GtpU():

    def __init__(self,localipaddr ,port):
        logging.info('Initializing gtpu')
        self.localipaddr = localipaddr
        self.port = port
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.bind((self.localipaddr,  self.port))
    
    def createGtpuPacket(self,rip,rteid,up_icmp_ue_ip,up_icmp_dest_ip):
        # build gtpu packet
        user_data_icmp = binascii.unhexlify("0800fb7026410001fd3cbf5c000000004fe00b0000000000101112131415161718191a1b1c1d1e1f202122232425262728292a2b2c2d2e2f3031323334353637")
        ip = IPPacket(up_icmp_ue_ip,up_icmp_dest_ip,socket.IPPROTO_ICMP,len(user_data_icmp))
        ip.assemble_ipv4_feilds()
        user_ipheader = ip.raw

        # get user header data
        user_ipheader_data =( user_ipheader + user_data_icmp )
        length_useripheaderdata = len(user_ipheader_data)
        teidhex = struct.pack(">I", rteid)
        gtpu_header = struct.pack('!HH', 12543, length_useripheaderdata) +  teidhex
        packet_gtpu_ip_icmp = ( gtpu_header + user_ipheader_data )
        return packet_gtpu_ip_icmp
    
    def StartGtpu(self, remoteip,rteid,up_icmp_ue_ip,up_icmp_dest_ip):
        logging.info("Sending 'gtpu' to %s", remoteip)
        self.remoteip = remoteip
        self.rteid = rteid
        self.up_icmp_ue_ip = up_icmp_ue_ip
        self.up_icmp_dest_ip = up_icmp_dest_ip
        self.packet_gtpu = self.createGtpuPacket(remoteip , rteid , up_icmp_ue_ip , up_icmp_dest_ip)
        self.sock.settimeout(5.0)
        self.sock.sendto(self.packet_gtpu, (self.remoteip,self.port))
        while True:
          try:
            msg, client = self.sock.recvfrom(1024)
          except socket.timeout:
            logging.info("no gtpu received")
            return


####GtpU##########################

##################################
class IPPacket:
  def __init__(self, src, dst,proto,lendata):
    self.src = src
    self.dst = dst
    self.proto = proto
    self.lendata = lendata
    self.raw = None
    self.create_ipv4_feilds_list()

  def assemble_ipv4_feilds(self):
    self.raw = struct.pack('!BBHHHBBH4s4s' , 
    self.ip_ver,   # IP Version 
    self.ip_dfc,   # Differentiate Service Feild
    self.ip_tol,   # Total Length
    self.ip_idf,   # Identification
    self.ip_flg,   # Flags
    self.ip_ttl,   # Time to leave
    self.ip_proto, # protocol
    self.ip_chk,   # Checksum
    self.ip_saddr, # Source IP 
    self.ip_daddr  # Destination IP 
    )
    return self.raw

  def create_ipv4_feilds_list(self):
    # ---- [Internet Protocol Version] ----
    ip_ver = 4
    ip_vhl = 5
    self.ip_ver = (ip_ver << 4 ) + ip_vhl
    # ---- [ Differentiate Servic Field ]
    ip_dsc = 0
    ip_ecn = 0
    self.ip_dfc = (ip_dsc << 2 ) + ip_ecn
    # ---- [ Total Length]
    self.ip_tol = self.lendata
    # ---- [ Identification ]
    self.ip_idf = 54321
    # ---- [ Flags ]
    ip_rsv = 0
    ip_dtf = 0
    ip_mrf = 0
    ip_frag_offset = 0
    self.ip_flg = (ip_rsv << 7) + (ip_dtf << 6) + (ip_mrf << 5) + (ip_frag_offset)
    # ---- [ Total Length ]
    self.ip_ttl = 255
    # ---- [ Protocol ]
    self.ip_proto = self.proto
    # ---- [ Check Sum ]
    self.ip_chk = 0
    # ---- [ Source Address ]
    self.ip_saddr = socket.inet_aton(self.src)
    # ---- [ Destination Address ]
    self.ip_daddr = socket.inet_aton(self.dst)
    return
####IPPacket######################
